﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TMcGillACP2_1
{
    public partial class frmMouser : Form
    {
        public frmMouser()
        {
            InitializeComponent();
        }

        private void frmMouser_MouseClick(object sender, MouseEventArgs e)
        {
            lblCord.Text = ("Clicked @ " + e.X + ", " + e.Y);

            if ((e.X > 250) && (e.Y < 250))
            {
                MessageBox.Show("Top Right");
            }
            if ((e.X < 250) && (e.Y < 250))
            {
                MessageBox.Show("Top Left");
            }
            if ((e.X > 250) && (e.Y > 250))
            {
                MessageBox.Show("Bottom Right");
            }
            if ((e.X < 250) && (e.Y > 250))
            {
                MessageBox.Show("Bottom Left");
            }
            if ((e.X == 250) && (e.Y == 250))
            {
                MessageBox.Show("Awesome Job!");
            }
        }
    }
}
