﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace TMcGillACP2_1
{
    public partial class frmInput : Form
    {
        StreamReader sr = new StreamReader("numbers.txt");
        StreamWriter sw = new StreamWriter("grades.txt");

        double[] grades = new double[6];
        double average, total;
        public frmInput()
        {
            InitializeComponent();
        }

        private void btnGrades_Click(object sender, EventArgs e)
        {
            fOutput();
            sw.Close();
        }

        private void frmInput_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < grades.Length; i++)
            {
                grades[i] = double.Parse(sr.ReadLine());
                lbxGrades.Items.Add(grades[i].ToString());
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public void fOutput()
        {
            sw.WriteLine("---------Grades---------");
            for (int i = 0; i < grades.Length; i++)
            {
                total += grades[i];
                sw.Write(grades[i].ToString());

                if (grades[i] >= 90)
                {
                    sw.WriteLine("-----A");
                }
                else if (grades[i] < 90 && grades[i] >= 80)
                {
                    sw.WriteLine("-----B");
                }
                else if (grades[i] < 80 && grades[i] >= 70)
                {
                    sw.WriteLine("-----C");
                }
                else if (grades[i] < 70 && grades[i] >= 60)
                {
                    sw.WriteLine("-----D");
                }
                else
                {
                    sw.WriteLine("-----F");
                }

            }
            sw.WriteLine("---------Total---------");

            sw.WriteLine(total.ToString());

            lbxGrades.Items.Add("---------Total---------");

            lbxGrades.Items.Add(total.ToString());

            lbxGrades.Items.Add("--------Average--------");

            lbxGrades.Items.Add((total / grades.Count()).ToString());

            sw.WriteLine("---------Total---------");

            sw.WriteLine((total / grades.Count()).ToString());
        }
    }
}
