﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
namespace TMcGillACP2_1
{
    public partial class frmSplash : Form
    {
        public frmSplash()
        {
            InitializeComponent();
        }

        private void bgWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            for (int i = 1; i <= 100; i++)
            {
                Thread.Sleep(50);
                bgWorker.ReportProgress(i);
            }
        }

        private void bgWorker_ProcessChanged(object sender, ProgressChangedEventArgs e)
        {
            pgbProgress.Value = e.ProgressPercentage;
            lblLoad.Text = "Progress: " + e.ProgressPercentage.ToString() + "%";
            if (pgbProgress.Value >= 100)
            {
                frmLinkList List = new frmLinkList();
                List.Show();
                this.Hide();
            }
        }

        private void frmSplash_Load(object sender, EventArgs e)
        {
            bgWorker.WorkerReportsProgress = true;
            bgWorker.RunWorkerAsync();
        }
    }
}
