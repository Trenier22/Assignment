﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TMcGillACP2_1
{
    public partial class frmLinkList : Form
    {
        LinkedList<string> strList = new LinkedList<string>();
        public frmLinkList()
        {
            InitializeComponent();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAbout about = new frmAbout();
            about.ShowDialog();
        }

        private void inputOutputToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmInput input = new frmInput();
            input.Show();
        }

        private void mouserToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmMouser mouse = new frmMouser();
            mouse.Show();
        }

        private void btnContains_Click(object sender, EventArgs e)
        {
            if (strList.Find(tbxInput.Text) == null)
            {
                MessageBox.Show(tbxInput.Text + " not found");
            }
            else
            {
                MessageBox.Show(tbxInput.Text + " is found");
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            lbxList.Items.Clear();
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            foreach (string s in strList)
            {
                lbxList.Items.Add(s);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            strList.AddLast(tbxInput.Text);
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (strList.Remove(tbxInput.Text))
            {
                strList.Remove(tbxInput.Text);
            }
            else
            {
                MessageBox.Show(tbxInput.Text + " not found");
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
