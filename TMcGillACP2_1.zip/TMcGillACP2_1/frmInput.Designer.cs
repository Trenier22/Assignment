﻿
namespace TMcGillACP2_1
{
    partial class frmInput
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnClose = new System.Windows.Forms.Button();
            this.btnGrades = new System.Windows.Forms.Button();
            this.lbxGrades = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(343, 247);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(99, 31);
            this.btnClose.TabIndex = 8;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnGrades
            // 
            this.btnGrades.Location = new System.Drawing.Point(343, 14);
            this.btnGrades.Name = "btnGrades";
            this.btnGrades.Size = new System.Drawing.Size(99, 31);
            this.btnGrades.TabIndex = 7;
            this.btnGrades.Text = "&Grades";
            this.btnGrades.UseVisualStyleBackColor = true;
            this.btnGrades.Click += new System.EventHandler(this.btnGrades_Click);
            // 
            // lbxGrades
            // 
            this.lbxGrades.FormattingEnabled = true;
            this.lbxGrades.Location = new System.Drawing.Point(152, 12);
            this.lbxGrades.Name = "lbxGrades";
            this.lbxGrades.Size = new System.Drawing.Size(106, 264);
            this.lbxGrades.TabIndex = 6;
            // 
            // frmInput
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(531, 293);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnGrades);
            this.Controls.Add(this.lbxGrades);
            this.Name = "frmInput";
            this.Text = "frmInput";
            this.Load += new System.EventHandler(this.frmInput_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnGrades;
        private System.Windows.Forms.ListBox lbxGrades;
    }
}